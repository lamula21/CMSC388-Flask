# Stores all configuration values
SECRET_KEY = b'\x020;yr\x91\x11\xbe"\x9d\xc1\x14\x91\xadf\xec'
MONGODB_HOST = "mongodb://localhost:27017/project_5_soln"
