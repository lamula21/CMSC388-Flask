# 3rd-party packages
from flask import render_template, request, redirect, url_for, flash
from flask_mongoengine import MongoEngine # enforce user login
from flask_login import ( # provides current_user
    LoginManager,
    current_user,
    login_user,
    logout_user,
    login_required,
)
# encode images
import io 
import base64

from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename

# stdlib
from datetime import datetime

# local
from . import app, bcrypt, client
from .forms import (
    SearchForm,
    MovieReviewForm,
    RegistrationForm,
    LoginForm,
    UpdateUsernameForm,
    UpdateProfilePicForm,
)
from .models import User, Review, load_user
from .utils import current_time

""" ************ View functions ************ """


@app.route("/", methods=["GET", "POST"])
def index():
    form = SearchForm()

    if form.validate_on_submit():
        return redirect(url_for("query_results", query=form.search_query.data))

    return render_template("index.html", form=form)


@app.route("/search-results/<query>", methods=["GET"])
def query_results(query):
    try:
        results = client.search(query)
    except ValueError as e:
        return render_template("query.html", error_msg=str(e))

    return render_template("query.html", results=results)


@app.route("/movies/<movie_id>", methods=["GET", "POST"])
def movie_detail(movie_id):
    try:
        result = client.retrieve_movie_by_id(movie_id)
    except ValueError as e:
        return render_template("movie_detail.html", error_msg=str(e))

    form = MovieReviewForm()
    if form.validate_on_submit():
        review = Review(
            commenter=current_user._get_current_object(),
            content=form.text.data,
            date=current_time(),
            imdb_id=movie_id,
            movie_title=result.title,
        )

        review.save()

        return redirect(request.path)

    reviews = Review.objects(imdb_id=movie_id)

    return render_template(
        "movie_detail.html", form=form, movie=result, reviews=reviews
    )

# DONE
@app.route("/user/<username>")
def user_detail(username):
    # grab user by finding username in the db
    user = User.objects(username=username).first()

    # if found, pull reviews from this username and pass to the rendertemplate
    if user is not None:
        user_review = Review.objects(commenter=user)
        image = get_b64_img(username)
    # if username not found, handle error and pass into rendertemplate
    else:
        error_msg = f'Error. The user {user.username} does not exist'
        return render_template('user_detail.html', error_msg=error_msg)
    return render_template('user_detail.html', username=username, user_review=user_review, image=image)

#DONE
@app.errorhandler(404)# Add decorator
def custom_404():
    return render_template('404.html'), 404


""" ************ User Management views ************ """

#DONE
@app.route("/register", methods=["GET", "POST"])
def register():

    # if user is auth, redirect to main page
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    # otherwise, proceed with registration form
    form = RegistrationForm()

    # if registeration form is submitted and validated
    if form.validate_on_submit():

        # Hash password for security
        hashed = bcrypt.generate_password_hash(form.password.data).decode('utf-8')

        # Create new User object (document) for our collection "User"s
        user = User(
            username=form.username.data, 
            email=form.email.data,
            password=hashed
            )
        
        # save user into db
        user.save()
        # redirect user to login route
        return redirect(url_for('login'))
    else:
        flash('username or email already taken. Try again!', 'warning')
    # Render the register.html page
    return render_template('register.html', title='Register', form=form)

#DONE
@app.route("/login", methods=["GET", "POST"])
def login():
    # if user is auth, redirect to main page
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    # otherwise, proceed with login form
    form = LoginForm()
    # if login form is submitted and validated
    if form.validate_on_submit():
        # find appropiate user in db
        user = User.objects(username=form.username.data).first()

        # if user exists and hash-password matches
        if (user is not None and bcrypt.check_password_hash(user.password, form.password.data)):
            # make user auth and
            login_user(user)
            flash('You are logged-in', 'success')
            # redirect to his account
            return redirect(url_for('account'))
        # otherwise prompt flash message
        flash('Please Log-in again', 'warning')

    # Render the login.html page
    # user no auth, not found or password no match, redirect to login page again to enter login form again
    return render_template('login.html', tittle='Login', form=form)


# DONE
@app.route("/logout")
@login_required # logged-in user access only
def logout():
    logout_user() # logout current user
    return redirect(url_for('index'))


#DONE
@app.route("/account", methods=["GET", "POST"])
@login_required # logged-in user access only
def account():
    # See how it is done in movie_detail.html
    updatePicForm = UpdateProfilePicForm()
    updateNameForm = UpdateUsernameForm()

    # Update Avatar
    if updatePicForm.validate_on_submit:
        # Check file security and file extension
        try:
            img = updatePicForm.picture.data
            filename = secure_filename(img.filename)
            content_type = f'images/{filename[-3:]}'
        except:
            flash('Error')

        # if current_user doesnt have pic, place one and save 
        if current_user.profile_pic.get() is None:
            current_user.profile_pic.put(img.stream, content_type=content_type)
        # if current_user already has pic, replace one and save
        else:
            current_user.profile_pic.replace(img.stream, content_type=content_type)
        
        # save user into db
        current_user.save()
        flash('Your avatar has been updated successfully!','success')
        return redirect(url_for('account'))

    # Update Name 
    if updateNameForm.validate_on_submit:
        if current_user.is_authenticated:
            user_object = User.objects(username=current_user.username)

            # if user doesnt exist with username in db, then modify username
            if User.objects(username=updateNameForm.username.data) is None: 
                user_object.modify(username=updateNameForm.username.data)
                user_object.save() # save modify user into db
                flash('Your username has been updated successfully!', 'success')
                return redirect(url_for('account'))
            else:
                flash('User already exists!','danger')
        else:
            return redirect(url_for('login'))

    # get user image    
    image = get_b64_img(current_user.username)
    
    return render_template(
        "account.html", 
        picform=updatePicForm,
        nameform=updateNameForm,
        image=image
    )

# encode and decode image
def get_b64_img(username):
    user= User.objects(username=username).first()
    bytes_im = io.BytesIO(user.profile_pic.read())
    image = base64.b64encode(bytes_im.getvalue()).decode()
    return image

# add this when user.is_auth. feature only for logged-in users
def dark_mode(username):
    user= User.objects(username=username).first()

    # if user.darkmode is true, then set the pages to darkmode
    # if user.darkmode is false, then set the pages to normal
    return True